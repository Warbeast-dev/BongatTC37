<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?= esc($title) ?> | Simple POS</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background-color: #f4f6f8;
            color: #212529;
            font-family: Arial, sans-serif;
        }

        header {
            padding: 20px;
            background-color: #172554;
            color: white;
        }

        header h1 {
            margin: 0 0 15px;
        }

        nav a {
            display: inline-block;
            margin-right: 8px;
            padding: 9px 14px;
            border-radius: 5px;
            background-color: #2563eb;
            color: white;
            text-decoration: none;
        }

        nav a:hover {
            background-color: #1d4ed8;
        }

        main {
            width: min(1000px, 92%);
            margin: 30px auto;
            padding: 25px;
            border-radius: 8px;
            background-color: white;
            box-shadow: 0 2px 10px rgb(0 0 0 / 10%);
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 12px;
            border: 1px solid #d1d5db;
            text-align: left;
        }

        th {
            background-color: #1e3a8a;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f1f5f9;
        }

        footer {
            padding: 20px;
            color: #64748b;
            text-align: center;
        }
    </style>
</head>

<body>
<header>
    <h1>Simple POS System</h1>

    <nav>
    <a href="/">Home</a>
    <a href="/about">About</a>
    <a href="/customers">Customer Accounts</a>
    <a href="/users">User Accounts</a>
</nav>
</header>

<main>