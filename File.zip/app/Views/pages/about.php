<section>
    <h2>About the Application</h2>

    <p>
        The Simple POS System demonstrates how routes, controllers, and
        views work together in CodeIgniter 4.
    </p>

    <p>
        Customer and user information currently comes from static PHP
        arrays. A database can replace these temporary data sources in a
        future version of the application.
    </p>
</section>