<section>
    <h2>Welcome to the Simple POS System</h2>

    <p>
        This website is the first version of a basic Point-of-Sale system
        created using CodeIgniter 4.
    </p>

    <p>
        Use the navigation menu to view information about the project,
        customer accounts, and user accounts.
    </p>
</section>