<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index(): string
    {
        $data = [
            'title' => 'User Accounts',

            'users' => [
                [
                    'username'  => 'admin01',
                    'full_name' => 'Alex Rivera',
                    'role'      => 'Administrator',
                ],
                [
                    'username'  => 'cashier01',
                    'full_name' => 'Bianca Flores',
                    'role'      => 'Cashier',
                ],
                [
                    'username'  => 'cashier02',
                    'full_name' => 'Daniel Cruz',
                    'role'      => 'Cashier',
                ],
                [
                    'username'  => 'manager01',
                    'full_name' => 'Erika Ramos',
                    'role'      => 'Manager',
                ],
                [
                    'username'  => 'staff01',
                    'full_name' => 'Francis Lim',
                    'role'      => 'Inventory Staff',
                ],
            ],
        ];

        return view('templates/header', $data)
            . view('users/users', $data)
            . view('templates/footer');
    }
}